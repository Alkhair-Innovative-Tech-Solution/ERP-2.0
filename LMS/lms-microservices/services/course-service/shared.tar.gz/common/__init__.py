# Shared common utilities

